import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function LoginScreen() {
  return (
    <View>
      <Text style={{fontSize:25}}>LoginScreen</Text>
    </View>
  )
}

const styles = StyleSheet.create({})