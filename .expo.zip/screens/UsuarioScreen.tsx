import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function UsuarioScreen() {
  return (
    <View>
      <Text style={{fontSize:25}}>UsuarioScreen</Text>
    </View>
  )
}

const styles = StyleSheet.create({})